
/*const mongoose = require('mongoose');
const Nota = mongoose.model('Nota');*/

const Nota = require('../models/notas');
const User = require('../models/users');

//GET Obtener todas las notas
module.exports.findAllNotas = (req, res) => {

    Nota.find((err, notas) => {
        if (err)
            return res
                .status(500)
                .jsonp({
                    error: 500,
                    mensaje: `${err.message}`
                });

        /*res
            .status(200)
            .jsonp(notas);*/

        if (notas && notas.length) {
            User.populate('notas', {path: "autor", select: '_id displayName email avatar'}, (err, notas) =>{
                res
                    .status(200)
                    .jsonp(notas);
            });
        } else {
            res.sendStatus(404);
        }


    });
};

// GET Obtener una nota
module.exports.findById = (req, res) => {

    Nota.findById(req.params.id, (err, nota) => {
       //if (err) return res.send(500, err);
        if (err)
            return res
                .status(404)
                .jsonp({
                    error: 404,
                    mensaje: 'No existe una nota con ese ID'
                });

        //res.status(200).jsonp(nota);
        User.populate(nota, {
            path: "autor",
            select: '_id displayName email avatar'
        }, (err, nota)=>{
            res.status(200).jsonp(nota)
        });


    });
};

//POST Nueva nota
module.exports.addNota = (req, res) => {

    let nuevaNota = new Nota({
       titulo: req.body.titulo,
       descripcion: req.body.descripcion,
       autor: req.user
    });

    nuevaNota.save(function(err, nota) {
       if (err)
           return res
               .status(500)
               .jsonp({
                   error: 500,
                   mensaje: `${err.message}`
               });

       User.populate(nota, {
           path: "autor",
           select: '_id displayName email avatar'
       }, (err, nota)=>{
           res.status(201).jsonp(nota)
       });

       //res.status(201).jsonp(nota);

    });

};

// PUT Editar una nota

module.exports.editNota = (req, res) => {

    Nota.findById(req.params.id, function (err, nota) {
        nota.titulo = req.body.titulo;
        nota.descripcion = req.body.descripcion;


        nota.save(function(err, nota) {
            if (err)
                return res
                    .status(500)
                    .jsonp({
                        error: 500,
                        mensaje: `${err.message}`
                    });
            //res.status(200).jsonp(nota);

            User.populate(nota, {
                path: "autor",
                select: '_id displayName email avatar'
            }, (err, nota)=>{
                res.status(200).jsonp(nota)
            });


        })


    });
};

// DELETE Borrar una nota

module.exports.deleteNota = (req, res) => {

    Nota.findById(req.params.id, (err, nota) => {
        if (nota === undefined)
            return res.sendStatus(404);

        nota.remove((err) => {
            if (err)
                return res
                    .status(500)
                    .jsonp({
                        error: 500,
                        mensaje: `${err.message}`
                    });
            res.sendStatus(204);
            //res.status(200).jsonp(nota);
        });
    });

};