
module.exports = {
    SECRET_TOKEN: 'miTitoTieneUnaTiendaYoTengoUnPimporritoQueEchaAguaFresquita',
    MONGODB_URI: 'mongodb://admin:admin@ds054118.mlab.com:54118/keeper'
};