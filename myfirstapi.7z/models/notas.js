const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let notaSchema = new Schema({
    titulo: String,
    descripcion: String,
    autor: {type: Schema.ObjectId, ref: 'User'}
});



module.exports = mongoose.model('Nota', notaSchema);