const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let categorySchema = new Schema({
    nombre: String,
    listaCampaigns: [{type: Schema.ObjectId, ref: 'Campaign'}]
});

module.exports = mongoose.model('Categoria', categorySchema);