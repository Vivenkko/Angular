const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let aportacionSchema = new Schema({
    fecha: {type: Date},
    cantidad: Number,
    user: {type: Schema.ObjectId, ref: 'User'},
    campaign: {type: Schema.ObjectId, ref: 'Campaign'},
    category: {type: Schema.ObjectId, ref: 'Caregory'}
});

module.exports = mongoose.model('Aportacion', aportacionSchema);