const express = require('express');
const userController = require('../controllers/users');
let router = express.Router();

router.post('/auth/register', userController.signUp);
router.post('/auth/login', userController.signIn);

module.exports = router;