const express = require('express');
const campaignController = require('../controllers/campaigns');

let router = express.Router();

router.get('/', campaignController.findAllCampaigns);
router.get('/:id', campaignController.findById);
router.post('/', campaignController.addCampaign);
router.put('/:id', campaignController.editCampaign);
router.delete('/:id', campaignController.deleteCampaign);
router.post('/', campaignController.addAportacion);

module.exports = router;