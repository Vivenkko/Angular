module.exports = {
    SECRET_TOKEN: 'hallowedbythyname',
    MONGODB_URI: ''
};