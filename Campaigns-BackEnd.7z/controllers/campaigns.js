//const Categoria = require('../models/categorias');
const User = require('../models/users');
const Campaign = require('../models/campaigns');
const Category = require('../models/categories');
const Aportacion = require('../models/aportaciones');

//GET Obtener todas las Campañas
module.exports.allCampaigns = (req, res) => {
    Campaign.find((err, campaigns) => {
        if (err) return res.status(500).jsonp({
            error: 500,
            mensaje: `${err.message}`
        });

        if (campaigns && campaigns.length) {

        } else {
            res.sendStatus(404);
        }
    });
};

// POST Unirse a una campaña
module.exports.joinCampaign = (req, res) => {

};

// GET Lista de mis campañas
module.exports.listaMisCampaigns = (req, res) => {
    User.find({_id: req.user}, {listaCampaigns: true}, (err, usuario) => {
        if (err) return res.status(404).jsonp({
            error: 404,
            mensaje: 'No existe ese usuario'
        });

        User.populate(usuario, {path: "listaCampaigns", select: '_id nombre'},(err, usuario) => {
            res.status(200).jsonp(usuario)
        });
    });
};

// GET Campaign/categories:campaign_id
module.exports.categoriesCampaigns = (req, res) => {
    Campaign.find(req.params.id, (err, campaign) => {
        if (err) return res.status(404).jsonp({
            error: 404,
            mensaje: 'No existe una campaña con ese ID'
        });

        Category.populate(campaign, {path: "listaCategories", select: '_id nombre'}, (err, campaign) => {
            res.status(200).jsonp(campaign)
        });
    });
};

// POST Añadir aportación
module.exports.addAportacion = (req, res) => {
    Campaign.find(req.params.id, (err, campaign) => {
        if (err) return res.status(404).jsonp({
            error: 404,
            mensaje: 'No existe una campaña con ese ID'
        });

        Aportacion.save(req.params.category, req.params.cantidad, (err, aportacion) => {
            res.status(200).jsonp(aportacion)
        });
    });
};


